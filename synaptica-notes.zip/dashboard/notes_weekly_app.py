"""Сводка встреч: таблица как для PowerPoint, клик команда → ФИО → заметки.

    python dashboard/notes_weekly_app.py
    python dashboard/notes_weekly_app.py \\
      --server.sslCertFile=/home/synaptica/certificates_06052026_1611/published_pem.txt \\
      --server.sslKeyFile=/home/synaptica/certificates_06052026_1611/private.key \\
      --server.headless true
"""

from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
STATIC = Path(__file__).resolve().parent / "notes_weekly_static"
for path in (str(ROOT), str(SCRIPTS)):
    if path not in sys.path:
        sys.path.insert(0, path)

from notes_weekly_report import build_report, fmt_minutes, has_person_name, person_name

app = FastAPI()
app.mount("/static", StaticFiles(directory=STATIC), name="static")

_DEMO_SKIP = {"aykolganova"}
_DEMO_NOTES = (
    {"login": "kseniam", "date": "2026-09-24", "start": "10:00", "kind": "клиентская", "contact": "звонок", "client": "ВТБ", "products": "NDF", "minutes": 90, "text": "Обсудили NDF CNH, клиент смотрит уровни."},
    {"login": "msmantserov", "date": "2026-09-25", "start": "14:00", "kind": "клиентская", "contact": "встреча", "client": "Газпромбанк", "products": "XCCY", "minutes": 120, "text": "XCCY USD/RUB, показали индикатив."},
    {"login": "mmat", "date": "2026-09-23", "start": "10:00", "kind": "смежники", "contact": "встреча", "client": "—", "products": "—", "minutes": 240, "text": "Гемба по пайплайну, первая половина дня."},
    {"login": "mmat", "date": "2026-09-28", "start": "15:30", "kind": "клиентская", "contact": "звонок", "client": "Райффайзен", "products": "IRS, NDF", "minutes": 180, "text": ""},
    {"login": "evyachkozlova", "date": "2026-09-26", "start": "11:00", "kind": "клиентская", "contact": "встреча", "client": "Юникредит", "products": "IRS", "minutes": 45, "participants": ["Козлова Елена Вячеславовна", "Зарезов Кирилл Михайлович"], "text": "IRS 3Y, ждут обратную связь."},
    {"login": "nalmaksimov", "date": "2026-09-29", "start": "16:00", "kind": "клиентская", "contact": "звонок", "client": "Ак Барс", "products": "MBK, REPO", "minutes": 60, "text": "МБК/репо, объём 60 млн."},
    {"login": "nalmaksimov", "date": "2026-09-24", "start": "12:30", "kind": "клиентская", "contact": "встреча", "client": "Совкомбанк", "products": "IRS", "minutes": 75, "participants": ["Максимов Никита Алексеевич", "Вукович София Станиславовна"], "text": "Встреча по IRS, клиент просит индикатив на 5 лет."},
    {"login": "vukovich.s.s", "date": "2026-09-23", "start": "09:30", "kind": "клиентская", "contact": "звонок", "client": "Альфа-Банк", "products": "NDF", "minutes": 40, "text": "Созвон по NDF EUR, смотрят объём на квартал."},
    {"login": "vukovich.s.s", "date": "2026-09-28", "start": "15:00", "kind": "клиентская", "contact": "встреча", "client": "Росбанк", "products": "option", "minutes": 90, "participants": ["Вукович София Станиславовна", "Манцеров Максим Станиславович"], "text": "Опцион на доллар, показали две структуры."},
    {"login": "svyablonskiy", "date": "2026-09-24", "start": "11:30", "kind": "клиентская", "contact": "встреча", "client": "Газпром", "products": "REPO", "minutes": 60, "text": "Репо под залог ОФЗ, срок до месяца."},
    {"login": "yymezentseva", "date": "2026-09-25", "start": "10:15", "kind": "клиентская", "contact": "звонок", "client": "Норникель", "products": "bond", "minutes": 35, "text": "Звонок по размещению, ждут решение казначейства."},
    {"login": "aniporoshin", "date": "2026-09-29", "start": "13:00", "kind": "клиентская", "contact": "встреча", "client": "РЖД", "products": "REPO", "minutes": 80, "participants": ["Порошин Андрей Николаевич", "Яблонский Сергей Владимирович"], "text": "Обсудили репо и график следующих встреч."},
    {"login": "riskripnikov", "date": "2026-09-23", "start": "16:45", "kind": "клиентская", "contact": "звонок", "client": "Лукойл", "products": "MBK", "minutes": 25, "text": "МБК овернайт, клиент подтвердил лимит."},
    {"login": "anandmelnikova", "date": "2026-09-26", "start": "14:20", "kind": "клиентская", "contact": "встреча", "client": "Сибур", "products": "MBK", "minutes": 50, "text": "Встреча по фондированию, смотрят неделю и месяц."},
    {"login": "avadimkuznetsova", "date": "2026-09-28", "start": "11:00", "kind": "клиентская", "contact": "звонок", "client": "Магнит", "products": "REPO", "minutes": 30, "participants": ["Кузнецова Анастасия Вадимовна", "Мельникова Анна Андреевна"], "text": "Короткий звонок по репо, перенесли детальный разбор."},
    {"login": "dasklyankin", "date": "2026-09-24", "start": "17:00", "kind": "клиентская", "contact": "встреча", "client": "МТС", "products": "IRS", "minutes": 70, "text": "IRS против ключевой, клиент сравнивает с прошлой сделкой."},
    {"login": "nygeyvandova", "date": "2026-09-25", "start": "09:00", "kind": "смежники", "contact": "встреча", "client": "—", "products": "—", "minutes": 45, "participants": ["Гейвандова Нателла Яновна", "Куликов Юрий Геннадьевич"], "text": "Внутренняя планёрка по пайплайну кредитных."},
    {"login": "ygkulikov", "date": "2026-09-29", "start": "10:40", "kind": "клиентская", "contact": "звонок", "client": "Северсталь", "products": "NDF", "minutes": 55, "text": "NDF на юань, объём уточнят в понедельник."},
    {"login": "emkotelnikova", "date": "2026-09-26", "start": "16:10", "kind": "клиентская", "contact": "встреча", "client": "X5", "products": "XCCY", "minutes": 65, "text": "Валютно-процентный своп, показали уровни на 3 года."},
    {"login": "kmizarezov", "date": "2026-09-23", "start": "13:30", "kind": "клиентская", "contact": "звонок", "client": "Тинькофф", "products": "option", "minutes": 40, "participants": ["Зарезов Кирилл Михайлович", "Козлова Елена Вячеславовна"], "text": "Звонок по опциону, клиент просит расчёт до пятницы."},
    {"login": "anpolyakov", "date": "2026-09-28", "start": "12:00", "kind": "клиентская", "contact": "встреча", "client": "Роснефть", "products": "IRS", "minutes": 95, "text": "Встреча по процентному свопу, договорились прислать индикатив."},
    {"login": "msmantserov", "date": "2026-09-29", "start": "09:45", "kind": "клиентская", "contact": "звонок", "client": "Ингосстрах", "products": "NDF", "minutes": 20, "text": "Короткий звонок, перенесли встречу на следующую неделю."},
)


def _words(n: int) -> str:
    piece = (
        "Встреча с казначейством: разобрали кривую, уровни IRS и NDF, "
        "сверку лимитов, сроки обратной связи и что показать на следующем созвоне. "
    )
    parts = []
    while len(" ".join(parts).split()) < n:
        parts.append(piece)
    return " ".join(" ".join(parts).split()[:n])


def _demo_item(note: dict) -> dict:
    return {
        "date": note["date"],
        "start": note.get("start") or "",
        "kind": note["kind"],
        "bucket": "client" if note["kind"] == "клиентская" else "adjacent",
        "contact": note.get("contact") or "",
        "minutes": note["minutes"],
        "client": note["client"],
        "bank": ", ".join(note.get("participants") or []),
        "products": note["products"],
        "duration": fmt_minutes(note["minutes"]),
        "text": note["text"] or _words(3000),
    }


def _apply_demo(report: dict) -> dict:
    people = list(report.get("people") or [])
    if any(p.get("items") and p.get("team_id") == "fi" for p in people):
        return report
    by_login = {p.get("login"): p for p in people if p.get("team_id") == "fi"}
    for note in _DEMO_NOTES:
        login = note["login"]
        if login in _DEMO_SKIP or not has_person_name(login):
            continue
        person = by_login.get(login)
        if person is None:
            person = {
                "name": person_name(login),
                "login": login,
                "team": "FI",
                "team_id": "fi",
                "notes": 0,
                "client": 0,
                "adjacent": 0,
                "external_minutes": 0,
                "meetings": 0,
                "avg_minutes": None,
                "items": [],
            }
            people.append(person)
            by_login[login] = person
        person["items"].append(_demo_item(note))
        person["notes"] += 1
        if note["kind"] == "клиентская":
            person["client"] += 1
            person["external_minutes"] += note["minutes"]
        else:
            person["adjacent"] += 1
    report["people"] = people
    fi_people = [p for p in people if p.get("team_id") == "fi"]
    staff = next((int(row.get("staff") or 0) for row in report.get("summary") or [] if row.get("team_id") == "fi"), 0)
    staff = staff or len(fi_people)
    client = sum(int(p.get("client") or 0) for p in fi_people)
    adjacent = sum(int(p.get("adjacent") or 0) for p in fi_people)
    ext = sum(int(p.get("external_minutes") or 0) for p in fi_people)
    for row in report.get("summary") or []:
        if row.get("team_id") == "fi":
            row["client"] = client
            row["adjacent"] = adjacent
            row["external_minutes"] = ext
            row["avg_client"] = round(client / staff, 2) if staff else 0
            row["avg_adjacent"] = round(adjacent / staff, 2) if staff else 0
        if row.get("label") == "Итого":
            others_c = sum(int(r.get("client") or 0) for r in report["summary"] if r.get("label") not in {"Итого", "FI Sales"})
            others_a = sum(int(r.get("adjacent") or 0) for r in report["summary"] if r.get("label") not in {"Итого", "FI Sales"})
            others_e = sum(int(r.get("external_minutes") or 0) for r in report["summary"] if r.get("label") not in {"Итого", "FI Sales"})
            tot_staff = int(row.get("staff") or staff)
            row["client"] = others_c + client
            row["adjacent"] = others_a + adjacent
            row["external_minutes"] = others_e + ext
            row["avg_client"] = round(row["client"] / tot_staff, 2) if tot_staff else 0
            row["avg_adjacent"] = round(row["adjacent"] / tot_staff, 2) if tot_staff else 0
    return report


@app.get("/")
def index():
    return FileResponse(
        STATIC / "index.html",
        headers={"Cache-Control": "no-cache"},
    )


def _day(value: str, end: bool) -> datetime:
    try:
        day = datetime.strptime(value, "%Y-%m-%d")
    except ValueError as exc:
        raise HTTPException(400, "дата в формате ГГГГ-ММ-ДД") from exc
    if end:
        return day.replace(hour=23, minute=59, second=59)
    return day


@app.get("/api/report")
def report(date_from: str | None = None, date_to: str | None = None):
    try:
        if date_from or date_to:
            if not date_from or not date_to:
                raise HTTPException(400, "нужны обе даты")
            start, end = _day(date_from, False), _day(date_to, True)
            if start > end:
                raise HTTPException(400, "начало позже конца")
            return build_report(date_from=start, date_to=end)
        return _apply_demo(build_report())
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, str(exc)) from exc


def main(argv: list[str] | None = None) -> None:
    import uvicorn

    parser = argparse.ArgumentParser()
    parser.add_argument("--server.sslCertFile", dest="ssl_cert", default=os.environ.get("SSL_CERTFILE", ""))
    parser.add_argument("--server.sslKeyFile", dest="ssl_key", default=os.environ.get("SSL_KEYFILE", ""))
    parser.add_argument("--server.headless", dest="headless", nargs="?", const="true", default="true")
    parser.add_argument("--server.port", dest="port", type=int, default=int(os.environ.get("PORT", "3333")))
    parser.add_argument("--server.address", dest="host", default="0.0.0.0")
    args = parser.parse_args(argv)
    kw = {"app": app, "host": args.host, "port": args.port}
    cert = (args.ssl_cert or "").strip()
    key = (args.ssl_key or "").strip()
    if cert and key:
        kw["ssl_certfile"] = cert
        kw["ssl_keyfile"] = key
    uvicorn.run(**kw)


if __name__ == "__main__":
    main()
